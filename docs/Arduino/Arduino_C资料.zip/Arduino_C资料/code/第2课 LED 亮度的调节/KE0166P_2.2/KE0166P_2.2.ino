int ledPin = 9; // 定义LED灯接数字口9

void setup () {
  pinMode (ledPin, OUTPUT); //初始化LED为输出模式
}
void loop () {
  for (int brightness = 0; brightness < 255; brightness = brightness + 1) {
    analogWrite (ledPin, brightness); //变亮
    delay (30); // 延迟30ms
  }
  for (int brightness = 255; brightness > 0; brightness = brightness - 1) {
    analogWrite (ledPin, brightness); //变暗
    delay (30); // 延迟30ms
  }
}
