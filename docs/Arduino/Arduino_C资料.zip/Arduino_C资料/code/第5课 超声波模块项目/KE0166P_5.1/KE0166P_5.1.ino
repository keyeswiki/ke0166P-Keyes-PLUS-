/*
  小乌龟智能车
  课程5.1
  超声波传感器
  http://www.keyes-robot.com
*/
int trigPin = 12;    // TRIG接数字口12
int echoPin = 13;    // Echo接数字口13
long duration, cm, inches;
void setup() {
  //启动串口
  Serial.begin (9600);
  //定义引脚模式
  pinMode(trigPin, OUTPUT);//输出
  pinMode(echoPin, INPUT);//输入
}
void loop() {
  digitalWrite(trigPin, LOW);//拉低2us
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);// 该传感器至少需要10us高电平触发
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  // 读取echo高电平时间
  duration = pulseIn(echoPin, HIGH);
  // 转换成距离
  cm = (duration / 2) / 29.1;
  inches = (duration / 2) / 74;
  Serial.print(inches);
  Serial.print("in, ");
  Serial.print(cm);
  Serial.print("cm");
  Serial.println();
  delay(200);
}
