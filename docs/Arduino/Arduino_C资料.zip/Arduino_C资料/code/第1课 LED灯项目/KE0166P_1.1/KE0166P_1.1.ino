void setup()
{
  pinMode(9, OUTPUT);// 设置数字口9为输出模式
}
void loop() // 反复循环
{
  digitalWrite(9, HIGH); // 设置数字口9为高电平，打开LED
  delay(100); // 等待0.1秒
  digitalWrite(9, LOW); // 设置数字口9为低电平，关闭LED
  delay(100); // 等待0.1秒
}
