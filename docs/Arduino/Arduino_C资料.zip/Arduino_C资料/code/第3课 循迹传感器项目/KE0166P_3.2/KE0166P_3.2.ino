int L_pin = 11;  //左边循迹传感器的引脚接数字口11
int M_pin = 7;  //中间循迹传感器的引脚接数字口7
int R_pin = 8;  //右边循迹传感器的引脚接数字口8
int val_L, val_R, val_M; // 定义三个传感器的变量值
void setup()
{
  Serial.begin(9600); // 启动串口监视器，并设置波特率为9600
  pinMode(L_pin, INPUT); // 左边循迹传感器设置为输入
  pinMode(M_pin, INPUT); // 中考循迹传感器设置为输入
  pinMode(R_pin, INPUT); // 右边循迹传感器设置为输入
  pinMode(9, OUTPUT);
}
void loop() {
  val_L = digitalRead(L_pin);//读取左边传感器的值
  val_R = digitalRead(R_pin);//读取右边传感器的值
  val_M = digitalRead(M_pin);//读取中间传感器的值
  Serial.print("left:");
  Serial.print(val_L);
  Serial.print(" middle:");
  Serial.print(val_M);
  Serial.print(" right:");
  Serial.println(val_R);

  if (val_L == LOW || val_M == LOW || val_R == LOW) //检测到信号
  {
    digitalWrite(9, HIGH);//LED 灯亮
  }
  else//如果没有检测到信号
  {
    digitalWrite(9, LOW);//LED 灯灭
  }
}
